import ray
from ray import serve
from fastapi import FastAPI

from transformers import pipeline

app = FastAPI()


@serve.deployment(num_replicas=2, ray_actor_options={"num_cpus": 1, "num_gpus": 1})
@serve.ingress(app)
class Translator:
    def __init__(self):
        # Load model
        self.model = "hello word"

    @app.post("/")
    def translate(self, text: str) -> str:
        return self.model


translator_app = Translator.bind()